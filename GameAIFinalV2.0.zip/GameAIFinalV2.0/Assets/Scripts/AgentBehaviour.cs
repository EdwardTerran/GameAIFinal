﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class AgentBehaviour : MonoBehaviour
{
    public float soundRadius = 10f;
    public float rotationSpeed = 5f;

    public float wanderRadius;
    public float wanderTimer;

    bool alerted;

    public Transform target;
    public Transform targetSelf;
    NavMeshAgent agent;

    float speed;
    private float timer;

    


    public float maxRayDistance = 25f;
    public LayerMask agentLayer;

    // Start is called before the first frame update
    void Start()
    {
        target = PlayerTracker.instance.player.transform;
        agent = GetComponent<NavMeshAgent>();
    }

    void OnEnable()
    {
        agent = GetComponent<NavMeshAgent>();
        timer = wanderTimer;
    }






        // Update is called once per frame
        void Update()
    {

        

        float distance = Vector3.Distance(target.position, transform.position);
        
        speed = getASpeed();

        float translation = Input.GetAxis("Vertical") * speed;
        float rotation = Input.GetAxis("Horizontal") * rotationSpeed;
        translation *= Time.deltaTime;
        rotation *= Time.deltaTime;
        transform.Translate(0, 0, translation);
        transform.Rotate(0, rotation, 0);

        Raycast();

        if (alerted)
        { agent.SetDestination(target.position + Vector3.one);

            float hideLength = 6f;

            if ((Vector3.Distance(target.position, targetSelf.position) >= hideLength))
            {
                alerted = false;
            }
        }

        else {
            

            timer += Time.deltaTime;

            if (timer >= wanderTimer)
            {
                Vector3 newPos = RandomNavSphere(transform.position, wanderRadius, -1);
                agent.SetDestination(newPos);
                timer = 0;
            }

            if ((distance <= soundRadius && speed >= 4f) || distance <= soundRadius / 2)

            {
                alerted = true;

                
            }
        }
    }

    public bool Raycast()
    {
        Vector3 forward = transform.TransformDirection(Vector3.forward);
        Ray ray = new Ray(transform.position, forward);
        RaycastHit hit;

        

        if (Physics.Raycast(ray, out hit, agentLayer))
        {
            Debug.DrawRay(transform.position, forward * 5, Color.green);
            return true;
        }
        else
        {
            Debug.DrawRay(transform.position, forward * 5, Color.red);
            return false;
        }

        
    }

    private float getASpeed()
    {
        GameObject thePlayer = GameObject.Find("A* Agent");
        AStarController playerScript = thePlayer.GetComponent<AStarController>();

        return playerScript.speed;
        
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, soundRadius);
    }

    public static Vector3 RandomNavSphere(Vector3 origin, float dist, int layermask)
    {
        Vector3 randDirection = Random.insideUnitSphere * dist;

        randDirection += origin;

        NavMeshHit navHit;

        NavMesh.SamplePosition(randDirection, out navHit, dist, layermask);

        return navHit.position;
    }
}
